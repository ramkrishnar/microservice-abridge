package com.configservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
