package com.simple.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simple.service.SimpleDaoImpl;
import com.simple.service.SimpleSer;
@Service
public class SimpleSerImpl implements SimpleSer{

	@Autowired
	private SimpleDaoImpl simpleDaoImpl;
	
	@Override
	public String getService(String msg) {
		// TODO Auto-generated method stub
		return simpleDaoImpl.Dao("service"+msg);
	}

}
