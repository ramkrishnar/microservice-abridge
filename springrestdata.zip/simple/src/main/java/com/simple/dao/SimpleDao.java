package com.simple.dao;

import org.springframework.stereotype.Repository;


public interface SimpleDao {
 String Dao(String msg);
}
