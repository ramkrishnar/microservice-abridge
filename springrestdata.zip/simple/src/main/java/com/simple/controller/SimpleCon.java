package com.simple.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simple.dao.SimpleSerImpl;

@RestController
public class SimpleCon {
     
	@Autowired
	private SimpleSerImpl simpleSerImpl;
	@GetMapping(value="/msg")
	public  String getmsg() {
		return simpleSerImpl.getService("controller");
	}
}
