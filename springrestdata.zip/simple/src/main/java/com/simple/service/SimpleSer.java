package com.simple.service;

import org.springframework.stereotype.Service;


public interface SimpleSer {

	String getService(String msg);
}
