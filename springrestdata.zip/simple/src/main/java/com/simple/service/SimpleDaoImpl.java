package com.simple.service;

import org.springframework.stereotype.Repository;

import com.simple.dao.SimpleDao;
@Repository
public class SimpleDaoImpl implements SimpleDao {

	@Override
	public String Dao(String msg) {
		return "Dao"+msg;
	}

}
