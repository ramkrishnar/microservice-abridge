package com.D4orderFeignService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class D4orderFeignServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(D4orderFeignServiceApplication.class, args);
	}

}
