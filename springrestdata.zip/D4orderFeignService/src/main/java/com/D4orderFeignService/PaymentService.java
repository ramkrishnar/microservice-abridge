package com.D4orderFeignService;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;


@FeignClient("PaymentService")

public interface PaymentService {

	@GetMapping(value="/")
   public String processOrder();
}
