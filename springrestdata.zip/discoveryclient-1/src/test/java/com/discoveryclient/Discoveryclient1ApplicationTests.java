package com.discoveryclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Discoveryclient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
