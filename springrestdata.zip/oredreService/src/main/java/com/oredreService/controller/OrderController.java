package com.oredreService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RefreshScope
@RestController
public class OrderController {
	
	@Value("${msg:config server not working}")
	private String mesg;

	@Autowired
	private RestTemplate restTemplate;
	@GetMapping(value="/")
	@HystrixCommand(fallbackMethod="defalutmsg")
	public String processOrder() {
		String msg=restTemplate.getForObject("http://PaymentService/", String.class);
		return "Order created ...  "+msg;
	}
	public String defalutmsg() {
		return "lazy Payment is enabled";
	}
}
