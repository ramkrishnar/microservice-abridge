package com.gateWayserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@SpringBootApplication
@EnableZuulProxy
public class GateWayserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(GateWayserverApplication.class, args);
	}

}
