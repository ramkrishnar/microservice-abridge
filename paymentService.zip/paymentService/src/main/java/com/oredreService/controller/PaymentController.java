package com.oredreService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class PaymentController {

	@Autowired
	private RestTemplate restTemplate;
	@GetMapping(value="/")
	public String paymentProcess() {
		String msg=restTemplate.getForObject("http://ShipmentService/", String.class);
		return "Payment created ...  "+msg;
	}
}
