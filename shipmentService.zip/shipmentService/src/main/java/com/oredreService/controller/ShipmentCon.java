package com.oredreService.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShipmentCon {
	

	@GetMapping(value="/")
	public String shipmentProcess() {
		return "shipment-processs";
	}
}
